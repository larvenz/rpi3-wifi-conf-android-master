# rpi3-wifi-conf-android
Simple Android application to configure wifi over bluetooth for a Raspberry Pi 3

Used with [this Python script](https://github.com/brendan-myers/rpi3-wifi-conf) running on the target Rasperry Pi.